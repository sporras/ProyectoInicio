drop database if exists proyecto;
create database proyecto;
use proyecto;

create table CatTipoUsuarios
(
	idTipoUsuario int not null primary key,
    descripcion nvarchar(500) not null
);

insert into CatTipoUsuarios values (1,"Concesionario");
insert into CatTipoUsuarios values (2,"Trabajador social");
insert into CatTipoUsuarios values (3,"Beneficiario");
insert into CatTipoUsuarios values (4,"Checador");



create table usuarios
(
	idUsuario int not null primary key,
    idTipoUsuario int not null,
    nombre nvarchar (500) not null,
    paterno nvarchar(500) not null,
    materno nvarchar(500) not null,
    FNacimiento nvarchar (500) not null,
    correo nvarchar (500) not null,
    contrasenia nvarchar(500) not null
);


alter table usuarios add foreign key (idTipoUsuario) references CatTipoUsuarios(idTipoUsuario);

create table RelHuellaUsuario
(
	idHuella int not null primary key,
    idUsuario int not null,
    huella nvarchar (1000) not null #RECONSIDERAR TIPO DE DATO
    
);

alter table RelHuellaUsuario add foreign key (idUsuario) references usuarios(idUsuario);

create table catDireccionesUsuario
(
	idDireccion int not null primary key,
	idUsuario int not null,
    delegacion nvarchar(500) not null,
    calle nvarchar(500) not null,
    interior nvarchar(500) not null,
    exterior int not null,
    CP int not null
);

alter table catDireccionesUsuario add foreign key (idUsuario) references usuarios(idUsuario);

create table CatUsuariosAsistencias
(
	idCatUsuariosAsistencias int not null primary key,
    idUsuario int not null,
    idHuella int not null,
    NumeroFaltas int not null

);

alter table CatUsuariosAsistencias add foreign key (idUsuario) references usuarios(idUsuario);
alter table CatUsuariosAsistencias add foreign key (idHuella) references RelHuellaUsuario(idHuella);

create table catDias
(
	idDia int not null primary key,
    dia nvarchar(500)
);

create table RelUsuariosDiasAsistencia
(
	idUsuario int not null,
    idDia int not null
);

alter table RelUsuariosDiasAsistencia add foreign key (idUsuario) references usuarios(idUsuario);
alter table RelUsuariosDiasAsistencia add foreign key (idDia) references catDias(idDia);

create table CatalogoContactos
(
	idContacto int not null primary key,
	tipo nvarchar(500)
);

create table relUsuarioContacto
(
	idUsuario int not null,
    idContacto int not null,
    descripcion nvarchar(500) not null
);

alter table relUsuarioContacto add foreign key (idUsuario) references usuarios(idUsuario);
alter table relUsuarioContacto add foreign key (idContacto) references CatalogoContactos(idContacto);

create table establecimientos #EVALUAR ESTA TABLA CON RESPECTO AL USUARIO CONCESIONARIO
(
	idEstablecimiento int not null primary key,
	nombreConcesionario nvarchar(500) not null,
    paternoConcesionario nvarchar(500) not null,
    maternoConcesionario nvarchar(500) not null,
    token nvarchar (500) not null

);

create table catDireccionesEstablecimientos
(
	idDireccion int not null primary key,
	idEstablecimiento int not null,
    delegacion nvarchar(500) not null,
    calle nvarchar(500) not null,
    interior nvarchar(500) not null,
    exterior int not null,
    CP int not null
);

alter table catDireccionesEstablecimientos add foreign key (idEstablecimiento) references establecimientos (idEstablecimiento);


create table relUsuarioEstablecimiento
(

	idEstablecimiento int not null,
	idUsuario int not null
);

alter table relUsuarioEstablecimiento add foreign key(idEstablecimiento) references establecimientos(idEstablecimiento);
alter table relUsuarioEstablecimiento add foreign key (idUsuario) references usuarios(idUsuario);

create table relEstablecimientoContacto
(
	idEstablecimiento int not null,
    idContacto int not null,
    descripcion nvarchar(500) not null
);

alter table relEstablecimientoContacto add foreign key(idEstablecimiento) references establecimientos(idEstablecimiento);

create table informacion
(
	idInformacion int not null primary key,
    nombreArchivo nvarchar(500) not null,
    descipcion nvarchar(500)
);

#Procedimiento para registro de usuarios

drop procedure if exists registraUsuarios;
delimiter **
create procedure registraUsuarios(in idTipo int, username nvarchar(500), pat nvarchar(500), mat nvarchar(500), fnac nvarchar(500), mail nvarchar(500), pass nvarchar(500))
begin
	declare mensaje nvarchar(500);
    declare identificador int;
    declare existencia int;
    
    set existencia=(select count(*) from usuarios where correo=mail); 
		
        case(existencia)
        
			when 1 then
			
				set mensaje="<font color=red size=80>Ya te has registrado con anterioridad</font>";
			
			when 0 then
				
                set identificador=(select ifnull(max(idUsuario),0)+1 from usuarios); 
                
                insert into usuarios values (identificador,idTipo,username,pat,mat,fnac,mail,md5(pass));
                
                set mensaje="<font color=green size=80>Registro existoso</font>";
                
               
        end case;
        
        select mensaje as respuesta;


end;**

delimiter ;

#Procedimiento para Iniciar Sesion

drop procedure if exists InicioSesion;
delimiter **
create procedure InicioSesion(in email nvarchar(500), contra nvarchar(500))

begin
	
    
	declare idUs int;
    declare idtipo int;
    declare tipo nvarchar(500);
    declare nameUs nvarchar(500);
    declare patern nvarchar(500);
    declare matern nvarchar(500);
    declare cumple nvarchar(500);
    declare mail nvarchar(500);
    
   set idUs= (select idUsuario  from usuarios where correo=email and contrasenia=md5(contra));
   set idtipo= (select idTipoUsuario  from usuarios where correo=email and contrasenia=md5(contra));
   set tipo=(select descripcion from CatTipoUsuarios where idTipoUsuario=idtipo);
   set nameUs= (select nombre  from usuarios where correo=email and contrasenia=md5(contra));
   set patern= (select paterno  from usuarios where correo=email and contrasenia=md5(contra));
   set matern= (select materno  from usuarios where correo=email and contrasenia=md5(contra));
   set cumple= (select FNacimiento  from usuarios where correo=email and contrasenia=md5(contra));
   set mail= (select correo  from usuarios where correo=email and contrasenia=md5(contra));
    
    select idUs as idUser, tipo as tipoUser, nameUs as nombreUser, patern as paternUser, matern as maternoUser,
			cumple as nacimiento, mail as corre, mail as clave;
end;**

delimiter ;

select*from usuarios;