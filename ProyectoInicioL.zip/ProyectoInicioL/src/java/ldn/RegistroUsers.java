/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ldn;

import java.sql.ResultSet;

/**
 *
 * @author Alumno
 */
public class RegistroUsers 
{
    
    
    public String entraDatos(int tipouser,String nombreuser,String apellidopat,String apellidomat, String fechanac,String email, String pass)
    {
        
        String regreso="";
        
        try
        {
            BD.cDatos conexion=new BD.cDatos();

            conexion.conectar(); //la variable solo se usa para empezar la conexion

            ResultSet sql= conexion.consulta("call registraUsuarios('"+tipouser+"','"+nombreuser+"','"+apellidopat+"','"+apellidomat+"','"+fechanac+"','"+email+"','"+pass+"');");
             /*variable de tipo resultset, Sirven para llamar los metodos de la base de datos */
            /*el procedimiento se escribe con todo punto y coma*/
            if(sql.next())
            {
               regreso = sql.getString("respuesta");
                //respuesta era el nombre de la base de datos 
                //la variable regreso nos enviara de vuelta al jsp 
            }
            
            conexion.cierraConexion();
           
        }catch(Exception e)
        {
            regreso=e.getMessage();
        }
        return regreso;
    }
    
}
